### Hexlet tests and linter status:
[![Actions Status](https://github.com/shashlfagai/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/shashlfagai/python-project-50/actions)
[![Test Coverage](https://api.codeclimate.com/v1/badges/41bd0075c1aca23278cf/test_coverage)](https://codeclimate.com/github/shashlfagai/python-project-50/test_coverage)

asciinema show
    https://asciinema.org/a/9DXMx1YpfTM4jIeszCp32QDfb
